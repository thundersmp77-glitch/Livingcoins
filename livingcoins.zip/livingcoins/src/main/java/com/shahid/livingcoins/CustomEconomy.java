package com.shahid.livingcoins;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class CustomEconomy extends JavaPlugin {

    private EconomyManager economy;

    @Override
    public void onEnable() {
        // Create config.yml if not exist
        saveDefaultConfig();

        // Initialize economy
        economy = new EconomyManager(this);

        // Register commands
        Commands commands = new Commands(economy);
        getCommand("livingcoins").setExecutor(commands);
        getCommand("lc").setExecutor(commands);

        // PlaceholderAPI hook
        boolean placeholderHooked = false;
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new LivingCoinsPlaceholders(this).register();
            placeholderHooked = true;
        }

        // --- Fancy Startup Banner
        getLogger().info("§6===============================");
        getLogger().info("§b██╗     ██╗███╗   ██╗██╗   ██╗");
        getLogger().info("§b██║     ██║████╗  ██║██║   ██║");
        getLogger().info("§b██║     ██║██╔██╗ ██║██║   ██║");
        getLogger().info("§b██║     ██║██║╚██╗██║╚██╗ ██╔╝");
        getLogger().info("§b███████╗██║██║ ╚████║ ╚████╔╝");
        getLogger().info("§b╚══════╝╚═╝╚═╝  ╚═══╝  ╚═══╝");
        getLogger().info("§eLivingCoins Plugin v1.0 Enabled!");
        getLogger().info("§ePlayers online: §a" + Bukkit.getOnlinePlayers().size());
        getLogger().info("§eCommands: §a/lc, /livingcoins");
        getLogger().info("§eDefault balance: §a" + getConfig().getDouble("default-balance"));
        getLogger().info("§ePlaceholderAPI hooked: §a" + placeholderHooked);
        getLogger().info("§6===============================");
    }

    @Override
    public void onDisable() {
        getLogger().info("§c===============================");
        getLogger().info("§cLivingCoins Plugin v1.0 Disabled!");
        getLogger().info("§c===============================");
    }

    public EconomyManager getEconomy() {
        return economy;
    }
}