package com.shahid.livingcoins;

import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.UUID;

public class EconomyManager {

    private final CustomEconomy plugin;
    private final HashMap<UUID, Double> balances = new HashMap<>();
    private File dataFile;
    private YamlConfiguration dataConfig;

    public EconomyManager(CustomEconomy plugin) {
        this.plugin = plugin;
        loadFile();
        loadAll();
    }

    private void loadFile() {
        dataFile = new File(plugin.getDataFolder(), "balances.yml");
        if (!dataFile.exists()) {
            dataFile.getParentFile().mkdirs();
            try { dataFile.createNewFile(); }
            catch (IOException e) { e.printStackTrace(); }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
    }

    public void loadAll() {
        if (dataConfig.getConfigurationSection("balances") == null) return;
        for (String key : dataConfig.getConfigurationSection("balances").getKeys(false)) {
            UUID uuid = UUID.fromString(key);
            double bal = dataConfig.getDouble("balances." + key);
            balances.put(uuid, bal);
        }
    }

    public void saveAll() {
        for (UUID uuid : balances.keySet()) {
            dataConfig.set("balances." + uuid.toString(), balances.get(uuid));
        }
        try { dataConfig.save(dataFile); }
        catch (IOException e) { e.printStackTrace(); }
    }

    public double getBalance(UUID uuid) {
        return balances.getOrDefault(uuid, 0.0);
    }

    public void addCoins(UUID uuid, double amount) {
        balances.put(uuid, getBalance(uuid) + amount);
    }

    public void takeCoins(UUID uuid, double amount) {
        balances.put(uuid, Math.max(0, getBalance(uuid) - amount));
    }

    public boolean hasEnough(UUID uuid, double amount) {
        return getBalance(uuid) >= amount;
    }
}