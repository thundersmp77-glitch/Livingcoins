package com.shahid.livingcoins;

import java.util.UUID;

public class PlayerData {

    private final UUID uuid;
    private double coins;

    public PlayerData(UUID uuid, double coins) {
        this.uuid = uuid;
        this.coins = coins;
    }

    public UUID getUUID() {
        return uuid;
    }

    public double getCoins() {
        return coins;
    }

    public void setCoins(double coins) {
        this.coins = coins;
    }

    public void addCoins(double amount) {
        this.coins += amount;
    }

    public void removeCoins(double amount) {
        this.coins = Math.max(0, this.coins - amount);
    }
}