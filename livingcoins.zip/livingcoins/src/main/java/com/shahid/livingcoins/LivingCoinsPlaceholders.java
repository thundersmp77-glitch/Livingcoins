package com.shahid.livingcoins;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class LivingCoinsPlaceholders extends PlaceholderExpansion {

    private final CustomEconomy plugin;

    public LivingCoinsPlaceholders(CustomEconomy plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "livingcoins"; // %livingcoins_balance%
    }

    @Override
    public @NotNull String getAuthor() {
        return "Shahid";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0";
    }

    @Override
    public String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "";
        if (params.equalsIgnoreCase("balance")) {
            return String.valueOf(plugin.getEconomy().getBalance(player.getUniqueId()));
        }
        return null;
    }
}