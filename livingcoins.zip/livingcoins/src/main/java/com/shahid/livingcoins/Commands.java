package com.shahid.livingcoins;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Commands implements CommandExecutor, TabCompleter {

    private final EconomyManager economy;
    private final List<String> subcommands = Arrays.asList("balance","give","take","help");

    public Commands(EconomyManager economy) {
        this.economy = economy;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase();

        if (args.length == 0) {
            sender.sendMessage("§eType §7/" + name + " help §efor commands.");
            return true;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("help")) {
            sender.sendMessage("§eLivingCoins Commands:");
            sender.sendMessage("§7/" + name + " balance");
            sender.sendMessage("§7/" + name + " give <player> <amount>");
            sender.sendMessage("§7/" + name + " take <player> <amount>");
            sender.sendMessage("§7/" + name + " help");
            return true;
        }

        if (sub.equals("balance")) {
            if (!(sender instanceof Player)) { sender.sendMessage("Console cannot check balance."); return true; }
            Player p = (Player) sender;
            p.sendMessage("§aYour balance: §e" + economy.getBalance(p.getUniqueId()));
            return true;
        }

        if (sub.equals("give")) {
            if (args.length < 3) { sender.sendMessage("§cUsage: /" + name + " give <player> <amount>"); return true; }
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) { sender.sendMessage("§cPlayer not found."); return true; }
            double amount = Double.parseDouble(args[2]);
            economy.addCoins(target.getUniqueId(), amount);
            sender.sendMessage("§aGave " + amount + " coins to " + target.getName());
            target.sendMessage("§aYou received " + amount + " coins.");
            return true;
        }

        if (sub.equals("take")) {
            if (args.length < 3) { sender.sendMessage("§cUsage: /" + name + " take <player> <amount>"); return true; }
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) { sender.sendMessage("§cPlayer not found."); return true; }
            double amount = Double.parseDouble(args[2]);
            economy.takeCoins(target.getUniqueId(), amount);
            sender.sendMessage("§aTaken " + amount + " coins from " + target.getName());
            target.sendMessage("§c" + amount + " coins removed from your balance.");
            return true;
        }

        sender.sendMessage("§cUnknown command. Type §7/" + name + " help §cfor commands.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            for (String s : subcommands) {
                if (s.startsWith(args[0].toLowerCase())) completions.add(s);
            }
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("take")) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) completions.add(p.getName());
                }
            }
        }
        return completions;
    }
}